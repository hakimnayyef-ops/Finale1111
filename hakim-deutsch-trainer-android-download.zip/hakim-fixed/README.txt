Hakim Deutsch Trainer – bereinigte PWA-Version

Dateien:
- index.html: bereinigte Haupt-App
- manifest.webmanifest: PWA-Manifest
- sw.js: Service Worker für Installation/Offline-App-Shell
- icons/: App-Icons 192 und 512 px
- firestore.rules: empfohlene Firestore-Regeln
- impressum.html / datenschutz.html: Vorlagen, bitte vor Veröffentlichung mit echten Angaben ergänzen

Wichtig vor Veröffentlichung:
1. Alle Dateien gemeinsam auf HTTPS hosten, z. B. Netlify.
2. In Firebase Console die Firestore Rules aus firestore.rules einfügen und veröffentlichen.
3. Impressum und Datenschutz mit echten Anbieterangaben ergänzen.
4. Premium-Codes in Firestore unter premiumCodes/{CODE} mit active:true und used:false anlegen.
